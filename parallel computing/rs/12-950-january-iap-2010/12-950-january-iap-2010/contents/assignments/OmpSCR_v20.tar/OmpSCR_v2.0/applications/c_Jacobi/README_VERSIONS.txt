
c_jacobi01.c -> Jacobi solver - OpenMP version, two parallel regions with one parallel loop each, the naive approach. 
c_jacobi02.c -> Jacobi solver - OpenMP version, 2 parallel loops in one parallel region (PR) 
c_jacobi03.c -> Jacobi solver - OpenMP version, 1 PR outside the iteration loop, 4 Barriers 

